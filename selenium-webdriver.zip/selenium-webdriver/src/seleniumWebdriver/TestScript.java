package seleniumWebdriver;

import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class TestScript {
	
	private InputStream in;
	private final static String FILE_PATH = "input.xlsx";// input.xlsx is removed.
	private XSSFWorkbook xssfWorkbook;
	private final static String BASEURL = "https://psych.liebes.top/st";
	
	public TestScript() throws IOException {
		// TODO Auto-generated constructor stub
		in = new FileInputStream(new File(FILE_PATH));
		xssfWorkbook = new XSSFWorkbook(in);
	}
	
	// get ids and urls from the .xlsx
	public Map<String, String> getElementsFromXlsx() {
		XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0);
		
		if (xssfSheet == null) {
			System.out.println("no values to return");
			return null;
		}
		
		Map<String, String> idAndUrl = new HashMap<>();
		
		for (int rowIndex = 0; rowIndex < 97; rowIndex++) {
			XSSFRow curRow = xssfSheet.getRow(rowIndex);
			if (curRow != null) {
				//System.out.println(String.valueOf(curRow.getCell(0).getStringCellValue()));
				XSSFCell xCellId = curRow.getCell(0);
				XSSFCell xCellUrl = curRow.getCell(1);
				
				if (xCellId.getCellType() == xCellId.CELL_TYPE_NUMERIC) {
					
					// format the number
					//DecimalFormat df = new DecimalFormat("#, ##0.00");
					Long numericId = (long)xCellId.getNumericCellValue();
					idAndUrl.put(String.valueOf(numericId), 
							String.valueOf(xCellUrl.getStringCellValue()));
				} else {
					idAndUrl.put(String.valueOf(xCellId.getStringCellValue()), 
							String.valueOf(xCellUrl.getStringCellValue()));
				}
				
			} else {
				System.out.println(".xlsx is broken and fail to read.");
				return null;
			}
		}
		
		return idAndUrl;
	}
	
	public List<String> getWrongIds() {
		List<String> wrongIds = new ArrayList<>();
		
		for (Map.Entry<String, String> entry: getElementsFromXlsx().entrySet()) {
			if (!isMatched(entry.getKey(), entry.getValue())) {
				wrongIds.add(entry.getKey());
			}
		}
		
		return wrongIds;
	}
	
	public boolean isMatched(String id, String url) {
		// config firefox webdriver
		WebDriver driver = new FirefoxDriver();
		driver.get(BASEURL);
		driver.findElement(By.id("username")).sendKeys(id);
		driver.findElement(By.id("password")).sendKeys(id.substring(4));
		System.out.println(id + "\t" + id.substring(4));
		driver.findElement(By.id("submitButton")).click();
		
		/*
		try {
			Thread.sleep(100);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}*/
		System.out.println(driver.findElement(By.xpath("//div[@class='login-box-body']/a/p[@class='login-box-msg']")).getText());
		if (driver.findElement(By.xpath("//div[@class='login-box-body']/a/p[@class='login-box-msg']")).getText()
				.equals(url)) {
			driver.close();
			return true;
		} else {
			driver.close();
			return false;
		}
	}
	
	public static void main(String[] args) {
		try {
			TestScript testScript = new TestScript();
			
			// print all the ids are not matched successfull
			List<String> inCorrectIds = new ArrayList<>();
			inCorrectIds = testScript.getWrongIds();
			
			for (String id: inCorrectIds) {
				System.out.println(id);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
